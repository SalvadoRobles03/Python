# Sebastian Garcia Gonzalez A01562565

lmc =  open("for.txt")

memoria = [0] * 100

for i in lmc:
    j = i[0:2]
    k = i[3:6]
    memoria.insert(int(j),int(k))

print(memoria)

inbox = 0
outbox = 0
calculadora = 0
pc = 0

while pc != len(memoria):
    x = memoria[pc]
    
    # entrada 
    if x == 901:
        inbox = int(input("input: "))
        calculadora = inbox
        pc += 1
    
    # salida
    elif x == 902:
        outbox = calculadora
        print(f"salida: {outbox}")
        pc += 1
    
    # suma 1xx
    elif x in range(100,200):
        y = x - 100
        calculadora = calculadora + memoria[y]
        pc += 1
    
    # resta 2xx
    elif x in range(200,300):
        y = x - 200
        calculadora = calculadora - memoria[y]
        pc += 1
    
    # guardar en memoria 3xx
    elif x in range(300,400):
        y = x - 300
        memoria[y] = calculadora
        pc += 1
        
    # cargar a calculadora 5xx
    elif x in range(500,600):
        y = x - 500
        calculadora = memoria[y]
        pc += 1
    
    # cambio contador de instrucciones 6xx
    elif x in range(600,700):
        y = x - 600
        pc = y
    
    # si el valor de calculadora es 0 entonces el contador se va al numero xx (7xx)
    elif x in range(700,800):
        y = x - 700
        if calculadora == 0:
            pc = y
        else:
            pc += 1
            
    # si el valor de calculadora >= 0 el contador se va al numero xx (8xx)
    elif x in range(800,900):
        y = x - 800
        if calculadora >= 0:
            pc = y
        else:
            pc += 1
    else:
        break
        
print(memoria)
