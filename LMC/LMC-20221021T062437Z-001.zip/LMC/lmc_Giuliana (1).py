import numpy as np

calculator=0 
contador=0
# genfromtxt convierte lo que esta en mi archivo de texto en array

Data = np.genfromtxt("sum.txt", dtype=str,
                     encoding=None, skip_footer=0)
lista_data=Data.tolist()#convierto en lista mi array
print(Data)
print(len(lista_data))
#print(lista_data)

print("Reading txt...")

for line in lista_data:
    print(line)

program = []
for i in range(100):
    program.append(0)

for i in range(len(lista_data)):
    if (lista_data[i][0:1] == '0'):   
        program[int(lista_data[i][0:2])] = int(lista_data[i][3:6])
    elif (lista_data[i][0:1] == '1'):
        program[int(lista_data[i][0:2])] = int(lista_data[i][3:6])
print(program)
def leerComandos(inst):
   global calculator #lo que hace global es utlizar variables de afuera d emi programa
   global contador
   if(inst>=100 and inst<200):
        inst=inst-100
        add1xx(inst)
   elif(inst>=200 and inst<300):
       inst=inst-200
       sub2xx(inst)
   elif(inst>=300 and inst<400):
       inst=inst-300
       store3xx(inst)
   elif(inst>=500 and inst<600):
       inst=inst-500
       load5xx(inst)
   elif(inst>=600 and inst<700):
       inst=inst-600
       bra6xx(inst)
   elif(inst>=700 and inst<800):
       inst=inst-700
       bra6xx(inst)
   elif(inst>=800 and inst<900):
       inst=inst-800
       drp8xx(inst)    
   elif(inst>=900 and inst<1000):
       inst=inst-900
       if(inst==1):
           input901()
       elif(inst==2):
           output902()
    
    



def input901():
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    valor=input("Number please: ")
    calculator=valor
    contador+=1
def store3xx(inst):
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    program[inst]=calculator
    contador+=1 
def add1xx(inst):
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    calculator=int(calculator)+int(program[inst])
    contador+=1
def sub2xx(inst):
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    calculator=int(calculator)-int(program[inst])
    contador+=1
def load5xx(inst):
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    calculator=program[inst]
    contador+=1
def output902():
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    print(calculator)
    contador+=1
def bra6xx(inst):
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    contador=inst #lo que estoy haciendo es que en calculadora agrego la direccion a donde quiero ir
def brz7xx(inst):#Si el acumulador (calculadora) contiene el valor 000, establece el valor xx en el contador de programa. En caso contrario no hace nada.
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    if(calculator==0):
        contador=inst
    else:
        contador+=1
def drp8xx(inst):#i el acumulador (calculadora) es 0 o positivo, establece el valor xx en el contador de programa. En caso contrario no hace nada.
    global calculator #lo que hace global es utlizar variables de afuera d emi programa
    global contador
    if(calculator >=0):
        contador=inst
    else:
        contador+=1



    
    
        
while(program[contador]!=000):
        leerComandos(program[contador])
        
print(program)


