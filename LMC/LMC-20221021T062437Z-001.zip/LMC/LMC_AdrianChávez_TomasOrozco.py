#Adrián Chávez A01568679
#Tomás Orozco A01562785

import sys
path = str(sys.argv[1])

memoria = ["0"]*100
calculadora = 0

f = open(path)
contents = f.readlines()
for i in contents:
    memoria[int(i[:2])] = i[3:6]

i = 0
while(memoria[i]!="000"):
    instruction = memoria[i]
    opcode = instruction[0]
    dirMemoria = int(instruction[1] + instruction[2])
    print("- Instruction counter: ",i," Instrucción: ",instruction," Calculadora: ", calculadora)
    i+=1
    if (instruction=="901"):  #INPUT
        calculadora = int(input("Escribe un valor: "))
    elif (instruction== "902"): #OUTPUT
        print("Output: ",calculadora)
    elif (opcode == "3"):  #STORE
        memoria[dirMemoria] = calculadora
    elif (opcode == "5"):   #LOAD
        calculadora = int(memoria[dirMemoria])
    elif (opcode == "1"):   #ADD
        calculadora += int(memoria[dirMemoria])
    elif (opcode == "2"):   #SUB
        calculadora -= int(memoria[dirMemoria])
    elif(opcode == "7"):    #BRANCH IF ZERO
        if(calculadora == 0):
            i = dirMemoria 
    elif(opcode == "8"):    #BRANCH IF ZERO OR POSITIVE
        if(calculadora >= 0):
            i = dirMemoria 
    elif(opcode == "6"):    #BRANCH ALWAYS
        i = dirMemoria 
    

print("- Instruction counter: ",i," Instrucción: ",memoria[i]," Calculadora: ", calculadora)
print("--- PROGRAM OVER ---")
    

