import sys
path = sys.argv[1]

with open(path) as file_object:
    lines = file_object.readlines()


mailbox = []
for i in range(100):
    mailbox.append(0)

for i in range(len(lines)):
    if (lines[i][0:1] == '0'):   
        mailbox[int(lines[i][0:2])] = int(lines[i][3:6])
    elif (lines[i][0:1] == '1'):
        mailbox[int(lines[i][0:2])] = int(lines[i][3:6])


icounter = 0
calculator = 0

def input901():
    print('Your Input: ')
    x = int(input())
    print(' ')
    return x

def output902():
    print('Calculator current value: ')
    print(calculator)

def store3xx(x):
    global calculator
    print(f'Storing calculator value ({calculator}) in mailbox #{x}' )
    mailbox[x] = calculator

def load5xx(x):
    global calculator
    print(f'Loading value from mailbox #{x} into calculator')
    calculator = mailbox[x]

def add1xx(x):
    global calculator
    print(f'Adding {x} to calculator')
    calculator = calculator + mailbox[x]

def sub2xx(x): #subs contents of mailbox xx
    global calculator
    print(f'Substracting value in mailbox #{x} to calculator ')
    calculator = calculator - mailbox[x]

def B6xx(x):
    global icounter 
    print(f'Branching to mailbox #{x}')
    icounter = x

def Bp8xx(x):  
    global calculator
    global icounter
    if (calculator > -1):
        print(f'Calculator is positive. Counter set to {x}')
        icounter = x
    else: 
        icounter = icounter +1

def Bz7xx(x):
    global calculator
    global icounter
    if (calculator == 0):
        icounter = x
    else: 
        icounter = icounter +1

print('=============')

### LMC Checker
while icounter != len(mailbox):
    x = mailbox[icounter]
    if x == 901:
        icounter = icounter + 1
        calculator = input901()
      
    elif x == 902:
        icounter = icounter + 1
        output902()

    elif x > 299 and x < 400:
        icounter = icounter + 1
        y = x - 300
        store3xx(y)
        
    elif x > 499 and x < 600:
        icounter = icounter + 1
        y = x - 500
        load5xx(y)
       
    elif x > 99 and x < 200:
        icounter = icounter + 1
        y = x - 100
        add1xx(y)
        
    elif x > 199 and x < 300:
        icounter = icounter + 1
        y = x - 200
        sub2xx(y)
        
    elif x > 599 and x < 700:
        y = x - 600
        B6xx(y)

    elif x > 799 and x < 900:
        y = x - 800
        Bp8xx(y)

    elif x > 699 and x < 800:
        y = x - 700
        Bz7xx(y)

    else:
        break


print(' ')
print('calculator')
print(calculator)
print('Mailbox: ')
print(mailbox)