#Natalia Valles
#Fernando Martínez

def inp(calculator):
    calculator=int(input("Ingresa un número: \n"))
    return calculator

def out(calculator):
    print(calculator)
    return calculator

def add(index, calculator):
    add=int(lista_prueba[int(index)])
    calculator = calculator + add
    return calculator
#print(calculator)

def sub(index, calculator):
    sub = int(lista_prueba[int(index)])
    calculator=calculator-sub
    return calculator

def sto(index,calculator):
    lista_prueba[int(index)]=calculator
    return calculator

def load(index,calculator):
    calculator=int(lista_prueba[int(index)])
    return calculator

def b(index,calculator,pc):
    pc=int(index)
    return pc

def bz(index,calculator,pc):
    if(calculator == 0):
        pc = int(index)
        return pc
    else:
        return pc+1

def bp(index,calculator,pc):
    if (calculator > -1):
        pc = int(index)
        return pc
    else:
        return pc + 1

switch_instruction = {
	901:inp,
	902: out,
	1: add,
	2: sub,
	3: sto,
	5: load,
    6: b,
    7: bz,
    8:bp
}
run=True
while(run==True):
    calculator = 0
    pc = 0

    lista_prueba = []
    for i in range(100):
        lista_prueba.insert(i, 000)

    read_file = str(input("Ingresa el nombre del archivo para leer: \n"))

    # Leer texto y convertirlo a list
    with open(read_file) as file:
        lines = file.readlines()
        lines = [line.rstrip() for line in lines]
    print(lines)

    # Rellenar los índices con los
    for l in range(len(lines)):
        index = int(lines[l][0:2])
        command = (lines[l][3:6])
        lista_prueba.insert(index, command)
    print(lista_prueba)

    while (pc<=100):
        #for pc in range (len(lista_prueba)):
        instruction=int(lista_prueba[pc][0:1])
        if(instruction==0):
            break
        elif(instruction<=5 or instruction==9):
            if (instruction == 9):
                instruction = int(lista_prueba[pc][0:3])
                calculator = switch_instruction.get(instruction)(calculator)
                pc=pc+1
            else:
                calculator=switch_instruction.get(instruction)(lista_prueba[pc][1:3],calculator)
                pc=pc+1
        else:
            pc=switch_instruction.get(instruction)(lista_prueba[pc][1:3],calculator,pc)
    print("Archivo ejecutado")
    print(lista_prueba)
    ans=input("Deseas leer otro programa? ")
    if(ans=="S" or ans=="s"):
        run=True
    else:
        print("Gracias por usar el programa, has salido")
        run=False





