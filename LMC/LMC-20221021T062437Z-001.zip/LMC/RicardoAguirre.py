
# Iniciar variables
calculadora = 0
contador = 0

with open("for.txt") as f:
    lineas = f.read().splitlines()

memoria = {}

for i in range(0, len(lineas)):
    key = int(lineas[i][0] + lineas[i][1])
    memoria[key] = int(lineas[i][3:])

print(memoria)


def sacarInstruccion():
    global memoria
    global contador
    if memoria.get(contador, -1) == 902:
        return 10
    elif memoria.get(contador, -1) == 901:
        return 9
    elif (memoria.get(contador, -1) > 99 or memoria.get(contador, -1) == 0) and (memoria.get(contador, -1) < 900):
        return int(str(memoria.get(contador))[0])
    else:
        contador+=1

def sacarDato(contador, memoria):
    return int(str(memoria[contador])[1:])


def sacarUlt2Calc(calculadora):
    return int(str(calculadora)[-2] + str(calculadora)[-1])


def add():
    global contador
    global memoria
    global calculadora
    calculadora += memoria[sacarDato(contador, memoria)]
    contador += 1


def sub():
    global contador
    global memoria
    global calculadora
    calculadora -= memoria[sacarDato(contador, memoria)]
    contador += 1


def sto():
    global contador
    global memoria
    global calculadora
    memoria[sacarDato(contador, memoria)] = calculadora
    contador += 1


def sta():
    global contador
    global memoria
    global calculadora
    memoria[sacarDato(contador, memoria)] = sacarUlt2Calc(calculadora)
    contador += 1


def load():
    global contador
    global memoria
    global calculadora
    calculadora = memoria[sacarDato(contador, memoria)]
    contador += 1


def b():
    global contador
    global memoria
    global calculadora
    contador = sacarDato(contador, memoria)


def bz():
    global contador
    global memoria
    global calculadora
    if calculadora == 0:
        contador = sacarDato(contador, memoria)
    else:
        contador+=1


def bp():
    global contador
    global memoria
    global calculadora
    if calculadora >= 0:
        contador = sacarDato(contador, memoria)
    else:
        contador +=1


def _input():
    global calculadora
    global contador
    calculadora = int(input())
    contador += 1


def _output():
    global calculadora
    global contador
    print(calculadora)
    contador += 1


def stop():
    global activo
    activo = False


instrucciones = {0: stop, 1: add, 2: sub, 3: sto, 4: sta, 5: load, 6: b, 7: bz, 8: bp, 9: _input, 10: _output}

activo = True
while activo == True:
    instruccion = sacarInstruccion()
    instrucciones.get(instruccion, print)()
